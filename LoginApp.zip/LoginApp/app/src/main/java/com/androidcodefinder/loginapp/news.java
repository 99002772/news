package com.androidcodefinder.loginapp;

public class news {

}
